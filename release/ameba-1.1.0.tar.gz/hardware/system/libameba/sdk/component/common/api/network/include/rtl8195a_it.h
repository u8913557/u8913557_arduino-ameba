
#ifndef __RTL8195A_IT_H_
#define __RTL8195A_IT_H_


int irq_alloc_wlan(void *contex);

#endif //__RTL8195A_IT_H_