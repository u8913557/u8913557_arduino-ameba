#ifndef _EXAMPLE_MJPEG_H
#define _EXAMPLE_MJPEG_H

void example_mjpeg(void);

#endif /* _EXAMPLE_FATFS_H */

